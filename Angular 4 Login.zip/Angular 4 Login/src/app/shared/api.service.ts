import { Injectable } from '@angular/core';

@Injectable()
export class ApiService {
  title = 'Angular 2';
}
